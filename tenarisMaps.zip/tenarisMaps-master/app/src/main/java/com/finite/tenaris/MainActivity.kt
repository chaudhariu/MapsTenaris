package com.finite.tenaris

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.finite.tenaris.databinding.ActivityMainBinding
import com.finite.tenaris.model.ShapeLatLongList
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolygonOptions

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMainBinding
    private val STROKE_WIDTH = 4f
    private var lastClick = ""
    private var showingIndonesiaMarkers = false
    private var showingMainMarkers = false
    private val indonesia = LatLng(-5.0, 106.0)
    private val singapore = LatLng(1.2737368391719859, 103.84123540000235)
    private val australia = LatLng(-31.955749040985843, 115.8616752820317)
    private var zoomValue: Map<String, Float> = mapOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        window.statusBarColor = Color.parseColor("#12171F")

        zoomValue = mapOf(
            "StartZoom" to 3.2f,
            getString(R.string.indonesia) to 6.00f,
            getString(R.string.indo_cilegon) to 15.3f,
            getString(R.string.indo_jakarta) to 15.3f,
            getString(R.string.indo_batam) to 18.0f,
            getString(R.string.Australia) to 20.0f,
            getString(R.string.singapore) to 18.5f
        )

        binding.apply {

            showChipsFor(getString(R.string.globe))

            chipIndonesia.setOnClickListener {
                clickedOnIndonesia()
            }

            chipSingapore.setOnClickListener {
                clickedOnSingapore()
            }

            chipAustralia.setOnClickListener {
                clickedOnAustralia()
            }

            chipIndoBatam.setOnClickListener {
                clickedOnBatam()
            }

            chipIndoCilegon.setOnClickListener {
                clickedOnCilegon()
            }

            chipIndoJakarta.setOnClickListener {
                clickedOnJakarta()
            }

            chipGlobe.setOnClickListener {
                zoomOutToGlobal()
                showChipsFor(getString(R.string.globe))
            }
        }

    }


    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.aubergine_map_style))

        initialiseGlobalMarkers()
        initialiseGlobalCameraAnimation()

        // Set a marker click listener to handle the click event
        mMap.setOnMarkerClickListener { marker ->
            when (marker.title) {
                getString(R.string.indonesia) -> clickedOnIndonesia()
                getString(R.string.indo_cilegon) -> clickedOnCilegon()
                getString(R.string.indo_jakarta) -> clickedOnJakarta()
                getString(R.string.indo_batam) -> clickedOnBatam()
                getString(R.string.Australia) -> clickedOnAustralia()
                getString(R.string.singapore) -> clickedOnSingapore()
            }
            true
        }

        mMap.setOnCameraMoveListener {
            if (mMap.cameraPosition.zoom <= 5.0f && !showingMainMarkers) {
                initialiseGlobalMarkers()
                showChipsFor(getString(R.string.globe))
            } else if (mMap.cameraPosition.zoom < 13.5f && lastClick == getString(R.string.indo_cilegon)) {
                initialiseIndonesiaMarkers()
                showChipsFor(getString(R.string.indonesia))
            } else if (mMap.cameraPosition.zoom < 16.0f && lastClick == getString(R.string.indo_batam)) {
                initialiseIndonesiaMarkers()
                showChipsFor(getString(R.string.indonesia))
            } else if (mMap.cameraPosition.zoom < 13.5f && lastClick == getString(R.string.indo_jakarta)) {
                initialiseIndonesiaMarkers()
                showChipsFor(getString(R.string.indonesia))
            }
        }
    }

    private fun clickedOnSingapore() {
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(singapore, zoomValue[getString(R.string.singapore)]!!),
            object : GoogleMap.CancelableCallback {
                override fun onFinish() {
                    showingMainMarkers = false
                    lastClick = getString(R.string.singapore)

                    mMap.clear()
                    mMap.addMarker(
                        MarkerOptions().position(
                            LatLng(
                                1.273533041652809, 103.84124612883843
                            )
                        )
                            .title("Tenaris Singapore")
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.yellow_marker))
                    )
                    showChipsFor(getString(R.string.singapore))
                }

                override fun onCancel() {}
            })

    }

    private fun clickedOnAustralia() {
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(australia, zoomValue[getString(R.string.Australia)]!!),
            object : GoogleMap.CancelableCallback {
                override fun onFinish() {
                    showingMainMarkers = false
                    lastClick = getString(R.string.Australia)

                    mMap.clear()

                    mMap.addMarker(
                        MarkerOptions().position(
                            LatLng(
                                -31.955749040985843, 115.8616752820317
                            )
                        )
                            .title("Tenaris Australia")
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.yellow_marker))
                    )
                    showChipsFor(getString(R.string.Australia))
                }

                override fun onCancel() {}
            })


    }

    private fun clickedOnIndonesia() {
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(indonesia, zoomValue[getString(R.string.indonesia)]!!),
            object : GoogleMap.CancelableCallback {
                override fun onFinish() {
                    initialiseIndonesiaMarkers()
                    showingIndonesiaMarkers = true

                    lastClick = getString(R.string.indonesia)
                    showChipsFor(getString(R.string.indonesia))
                }

                override fun onCancel() {}
            })
    }

    private fun clickedOnCilegon() {
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(
                    -5.9938750447716895,
                    106.02084583671159
                ), zoomValue[getString(R.string.indo_cilegon)]!!

            ), object : GoogleMap.CancelableCallback {
                override fun onFinish() {
                    lastClick = getString(R.string.indo_cilegon)
                    initCilegonPolygon()
                    showChipsFor(getString(R.string.indo_cilegon))
                }

                override fun onCancel() {}
            }
        )
    }

    private fun clickedOnJakarta() {
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(
                    -6.2235842353248065, 106.79876524629705
                ), zoomValue[getString(R.string.indo_jakarta)]!!

            ), object : GoogleMap.CancelableCallback {
                override fun onFinish() {
                    mMap.addMarker(
                        MarkerOptions().position(
                            LatLng(
                                -6.223587568326248,
                                106.79876994016284
                            )
                        )
                            .title(getString(R.string.indo_jakarta))
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.yellow_marker))
                    )
                    showingIndonesiaMarkers = false
                    lastClick = getString(R.string.indo_jakarta)
                    showChipsFor(getString(R.string.indo_jakarta))
                }

                override fun onCancel() {}
            }
        )
    }

    private fun clickedOnBatam() {
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(
                    1.1142353303207022,
                    104.1388075099539
                ), zoomValue[getString(R.string.indo_batam)]!!

            ), object : GoogleMap.CancelableCallback {
                override fun onFinish() {
                    initHydrilBatamPolygon()
                    lastClick = getString(R.string.indo_batam)
                    showChipsFor(getString(R.string.indo_batam))
                }

                override fun onCancel() {}
            }
        )
    }

    private fun zoomOutToGlobal() {
        mMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(LatLng(-5.0, 106.0), zoomValue["StartZoom"]!!),
            object : GoogleMap.CancelableCallback {
                override fun onFinish() {
                    initialiseGlobalMarkers()
                }

                override fun onCancel() {}
            })
    }

    private fun initialiseGlobalCameraAnimation() {
        val newCameraPosition = CameraPosition.Builder()
            .target(LatLng(-5.0, 106.0))
            .zoom(zoomValue["StartZoom"]!!)
            .build()

        mMap.moveCamera(CameraUpdateFactory.newCameraPosition(newCameraPosition))
    }

    private fun initialiseGlobalMarkers() {
        mMap.clear()
        lastClick = ""
        showingMainMarkers = true
        showingIndonesiaMarkers = false
        mMap.addMarker(MarkerOptions().position(indonesia).title(getString(R.string.indonesia)))
        mMap.addMarker(MarkerOptions().position(singapore).title(getString(R.string.singapore)))
        mMap.addMarker(MarkerOptions().position(australia).title(getString(R.string.Australia)))
    }

    private fun initialiseIndonesiaMarkers() {
        if (!showingIndonesiaMarkers) {
            showingIndonesiaMarkers = true
            showingMainMarkers = false
            mMap.clear()

            mMap.addMarker(
                MarkerOptions().position(
                    LatLng(
                        -5.9938750447716895,
                        106.02094583671159
                    )
                )
                    .title(getString(R.string.indo_cilegon))
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.yellow_marker))
            )
            mMap.addMarker(
                MarkerOptions().position(
                    LatLng(
                        -6.223580569023194,
                        106.79875921132675
                    )
                )
                    .title(getString(R.string.indo_jakarta))
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.yellow_marker))
            )
            mMap.addMarker(
                MarkerOptions().position(
                    LatLng(
                        1.1142353303207022,
                        104.1388075099539
                    )
                )
                    .title(getString(R.string.indo_batam))
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.yellow_marker))
            )
        }
    }

    private fun initCilegonPolygon() {
        mMap.clear()
        showingIndonesiaMarkers = false
        showingMainMarkers = false
        val tenarisSPIJPolygon1 =
            getPolygonOptions(ShapeLatLongList().tenarisSpijPolygon1, "#140DF2", "#70CCC58F", 6f)
        val tenarisSPIJPolygon2 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon2,
            "#00B51A",
            "#7000B51A",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon3 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon3,
            "#FE2905",
            "#70FE2905",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon4 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon4,
            "#FE2905",
            "#70FE2905",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon5 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon5,
            "#FE2905",
            "#70FE2905",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon6 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon6,
            "#28713E",
            "#7028713E",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon7 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon7,
            "#140DF2",
            "#70140DF2",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon8 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon8,
            "#EDAB56",
            "#70EDAB56",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon9 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon9,
            "#28713E",
            "#7028713E",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon10 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon10,
            "#7AACAC",
            "#707AACAC",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon11 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon11,
            "#7AACAC",
            "#707AACAC",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon12 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon12,
            "#E1A6AD",
            "#70E1A6AD",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon13 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon13,
            "#FE2905",
            "#70FE2905",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon14 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon14,
            "#00B51A",
            "#7000B51A",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon15 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon15,
            "#C930CF",
            "#70C930CF",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon16 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon16,
            "#EAF044",
            "#70EAF044",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon17 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon17,
            "#C930CF",
            "#70C930CF",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon18 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon18,
            "#00B51A",
            "#7000B51A",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon19 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon19,
            "#BE4E24",
            "#70BE4E24",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon20 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon20,
            "#BE4E24",
            "#70BE4E24",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon21 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon21,
            "#EDAB56",
            "#70EDAB56",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon22 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon22,
            "#7AACAC",
            "#707AACAC",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon23 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon23,
            "#E1A6AD",
            "#70E1A6AD",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon24 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon24,
            "#C73F4A",
            "#70C73F4A",
            STROKE_WIDTH
        )

        val tenarisSPIJPolygon26 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon26,
            "#0F4336",
            "#700F4336",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon27 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon27,
            "#C930CF",
            "#70C930CF",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon28 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon28,
            "#E1A6AD",
            "#70E1A6AD",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon29 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon29,
            "#EDAB56",
            "#70EDAB56",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon30 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon30,
            "#EDAB56",
            "#70EDAB56",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon31 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon31,
            "#FE2905",
            "#70FE2905",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon32 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon32,
            "#0F4336",
            "#700F4336",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon33 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon33,
            "#E1A6AD",
            "#70E1A6AD",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon34 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon34,
            "#EAF044",
            "#70EAF044",
            STROKE_WIDTH
        )

        val tenarisSPIJPolygon35 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon35,
            "#DEA691",
            "#70DEA691",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon36 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon36,
            "#FE2905",
            "#70FE2905",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon37 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon37,
            "#BE4E24",
            "#70BE4E24",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon38 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon38,
            "#DEA691",
            "#70DEA691",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon39 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon39,
            "#DEA691",
            "#70DEA691",
            STROKE_WIDTH
        )
        val tenarisSPIJPolygon40 = getPolygonOptions(
            ShapeLatLongList().tenarisSpijPolygon40,
            "#BE4E24",
            "#70BE4E24",
            STROKE_WIDTH
        )


        mMap.addPolygon(tenarisSPIJPolygon1)
        mMap.addPolygon(tenarisSPIJPolygon2)
        mMap.addPolygon(tenarisSPIJPolygon3)
        mMap.addPolygon(tenarisSPIJPolygon4)
        mMap.addPolygon(tenarisSPIJPolygon5)
        mMap.addPolygon(tenarisSPIJPolygon6)
        mMap.addPolygon(tenarisSPIJPolygon7)
        mMap.addPolygon(tenarisSPIJPolygon8)
        mMap.addPolygon(tenarisSPIJPolygon9)
        mMap.addPolygon(tenarisSPIJPolygon10)
        mMap.addPolygon(tenarisSPIJPolygon11)
        mMap.addPolygon(tenarisSPIJPolygon12)
        mMap.addPolygon(tenarisSPIJPolygon13)
        mMap.addPolygon(tenarisSPIJPolygon14)
        mMap.addPolygon(tenarisSPIJPolygon15)
        mMap.addPolygon(tenarisSPIJPolygon16)
        mMap.addPolygon(tenarisSPIJPolygon17)
        mMap.addPolygon(tenarisSPIJPolygon18)
        mMap.addPolygon(tenarisSPIJPolygon19)
        mMap.addPolygon(tenarisSPIJPolygon20)
        mMap.addPolygon(tenarisSPIJPolygon21)
        mMap.addPolygon(tenarisSPIJPolygon22)
        mMap.addPolygon(tenarisSPIJPolygon23)
        mMap.addPolygon(tenarisSPIJPolygon24)

        mMap.addPolygon(tenarisSPIJPolygon26)
        mMap.addPolygon(tenarisSPIJPolygon27)
        mMap.addPolygon(tenarisSPIJPolygon28)
        mMap.addPolygon(tenarisSPIJPolygon29)
        mMap.addPolygon(tenarisSPIJPolygon30)
        mMap.addPolygon(tenarisSPIJPolygon31)
        mMap.addPolygon(tenarisSPIJPolygon32)
        mMap.addPolygon(tenarisSPIJPolygon33)
        mMap.addPolygon(tenarisSPIJPolygon34)

        mMap.addPolygon(tenarisSPIJPolygon35)
        mMap.addPolygon(tenarisSPIJPolygon36)
        mMap.addPolygon(tenarisSPIJPolygon37)
        mMap.addPolygon(tenarisSPIJPolygon38)
        mMap.addPolygon(tenarisSPIJPolygon39)
        mMap.addPolygon(tenarisSPIJPolygon40)

    }

    private fun initHydrilBatamPolygon() {

        mMap.clear()
        showingIndonesiaMarkers = false
        showingMainMarkers = false
        val HydrilBase = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilBasePolygon,
            "#A4ABBD",
            "#70FFA5A6",
            7f
        )
        val HydrilPolygon1 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon1,
            "#FEF083",
            "#70FEF083",
            STROKE_WIDTH
        )
        val HydrilPolygon2 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon2,
            "#D0D2E9",
            "#70D0D2E9",
            STROKE_WIDTH
        )
        val HydrilPolygon3 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon3,
            "#B1E1AD",
            "#70B1E1AD",
            STROKE_WIDTH
        )
        val HydrilPolygon4 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon4,
            "#FEF083",
            "#70FEF083",
            STROKE_WIDTH
        )
        val HydrilPolygon5 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon5,
            "#6AD3FB",
            "#706AD3FB",
            STROKE_WIDTH
        )
        val HydrilPolygon6 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon6,
            "#6AD3FB",
            "#706AD3FB",
            STROKE_WIDTH
        )
        val HydrilPolygon7 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon7,
            "#AA99DD",
            "#90AA99DD",
            STROKE_WIDTH
        )
        val HydrilPolygon8 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon8,
            "#FEF083",
            "#70FEF083",
            STROKE_WIDTH
        )
        val HydrilPolygon9 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon9,
            "#B1E1AD",
            "#70B1E1AD",
            STROKE_WIDTH
        )
        val HydrilPolygon10 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon10,
            "#FEF083",
            "#70FEF083",
            STROKE_WIDTH
        )
        val HydrilPolygon11 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon11,
            "#B1E1AD",
            "#70B1E1AD",
            STROKE_WIDTH
        )
        val HydrilPolygon12 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon12,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon13 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon13,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon14 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon14,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon15 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon15,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon16 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon16,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon17 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon17,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon18 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon18,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon19 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon19,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon20 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon20,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon21 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon21,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon22 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon22,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon23 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon23,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon24 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon24,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon25 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon25,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon26 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon26,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon27 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon27,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon28 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon28,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon29 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon29,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon30 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon30,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon31 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon31,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon32 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon32,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )
        val HydrilPolygon33 = getPolygonOptions(
            ShapeLatLongList().tenarisHydrilPolygon33,
            "#FF543834",
            "#764F4A",
            STROKE_WIDTH
        )

        mMap.addPolygon(HydrilBase)
        mMap.addPolygon(HydrilPolygon1)
        mMap.addPolygon(HydrilPolygon2)
        mMap.addPolygon(HydrilPolygon3)
        mMap.addPolygon(HydrilPolygon4)
        mMap.addPolygon(HydrilPolygon5)
        mMap.addPolygon(HydrilPolygon6)
        mMap.addPolygon(HydrilPolygon7)
        mMap.addPolygon(HydrilPolygon8)
        mMap.addPolygon(HydrilPolygon9)
        mMap.addPolygon(HydrilPolygon10)
        mMap.addPolygon(HydrilPolygon11)
        mMap.addPolygon(HydrilPolygon12)
        mMap.addPolygon(HydrilPolygon13)
        mMap.addPolygon(HydrilPolygon14)
        mMap.addPolygon(HydrilPolygon15)
        mMap.addPolygon(HydrilPolygon16)
        mMap.addPolygon(HydrilPolygon17)
        mMap.addPolygon(HydrilPolygon18)
        mMap.addPolygon(HydrilPolygon19)
        mMap.addPolygon(HydrilPolygon20)
        mMap.addPolygon(HydrilPolygon21)
        mMap.addPolygon(HydrilPolygon22)
        mMap.addPolygon(HydrilPolygon23)
        mMap.addPolygon(HydrilPolygon24)
        mMap.addPolygon(HydrilPolygon25)
        mMap.addPolygon(HydrilPolygon26)
        mMap.addPolygon(HydrilPolygon27)
        mMap.addPolygon(HydrilPolygon28)
        mMap.addPolygon(HydrilPolygon29)
        mMap.addPolygon(HydrilPolygon30)
        mMap.addPolygon(HydrilPolygon31)
        mMap.addPolygon(HydrilPolygon32)
        mMap.addPolygon(HydrilPolygon33)

    }

    private fun getPolygonOptions(
        latLongList: MutableList<LatLng>,
        strokeColor: String,
        fillColor: String,
        width: Float
    ): PolygonOptions {
        return PolygonOptions()
            .addAll(latLongList)
            .strokeWidth(width)
            .strokeColor(Color.parseColor(strokeColor))
            .fillColor(Color.parseColor(fillColor))
    }

    private fun showChipsFor(location : String ) {
        when (location) {
            getString(R.string.indonesia) -> {
                binding.apply {
                    chipAustralia.visibility = android.view.View.GONE
                    chipSingapore.visibility = android.view.View.GONE

                    chipGlobe.visibility = android.view.View.VISIBLE
                    chipInfo.visibility = android.view.View.GONE
                    chipIncharge.visibility = android.view.View.VISIBLE

                    chipIndonesia.visibility = android.view.View.GONE
                    chipIndoCilegon.visibility = android.view.View.VISIBLE
                    chipIndoJakarta.visibility = android.view.View.VISIBLE
                    chipIndoBatam.visibility = android.view.View.VISIBLE
                }
            }
            getString(R.string.Australia) -> {
                binding.apply {
                    chipAustralia.visibility = android.view.View.GONE
                    chipSingapore.visibility = android.view.View.GONE

                    chipGlobe.visibility = android.view.View.VISIBLE
                    chipInfo.visibility = android.view.View.GONE
                    chipIncharge.visibility = android.view.View.VISIBLE

                    chipIndonesia.visibility = android.view.View.GONE
                    chipIndoCilegon.visibility = android.view.View.GONE
                    chipIndoJakarta.visibility = android.view.View.GONE
                    chipIndoBatam.visibility = android.view.View.GONE
                }
            }
            getString(R.string.singapore) -> {
                binding.apply {
                    chipAustralia.visibility = android.view.View.GONE
                    chipSingapore.visibility = android.view.View.GONE

                    chipGlobe.visibility = android.view.View.VISIBLE
                    chipInfo.visibility = android.view.View.GONE
                    chipIncharge.visibility = android.view.View.VISIBLE

                    chipIndonesia.visibility = android.view.View.GONE
                    chipIndoCilegon.visibility = android.view.View.GONE
                    chipIndoJakarta.visibility = android.view.View.GONE
                    chipIndoBatam.visibility = android.view.View.GONE
                }
            }
            getString(R.string.indo_cilegon) -> {
                binding.apply {
                    chipAustralia.visibility = android.view.View.GONE
                    chipSingapore.visibility = android.view.View.GONE

                    chipGlobe.visibility = android.view.View.VISIBLE
                    chipInfo.visibility = android.view.View.VISIBLE
                    chipIncharge.visibility = android.view.View.VISIBLE

                    chipIndonesia.visibility = android.view.View.VISIBLE
                    chipIndoCilegon.visibility = android.view.View.GONE
                    chipIndoJakarta.visibility = android.view.View.GONE
                    chipIndoBatam.visibility = android.view.View.GONE
                }
            }
            getString(R.string.indo_batam) -> {
                binding.apply {
                    chipAustralia.visibility = android.view.View.GONE
                    chipSingapore.visibility = android.view.View.GONE

                    chipGlobe.visibility = android.view.View.VISIBLE
                    chipInfo.visibility = android.view.View.VISIBLE
                    chipIncharge.visibility = android.view.View.VISIBLE

                    chipIndonesia.visibility = android.view.View.VISIBLE
                    chipIndoCilegon.visibility = android.view.View.GONE
                    chipIndoJakarta.visibility = android.view.View.GONE
                    chipIndoBatam.visibility = android.view.View.GONE
                }
            }
            getString(R.string.indo_jakarta) -> {
                binding.apply {
                    chipAustralia.visibility = android.view.View.GONE
                    chipSingapore.visibility = android.view.View.GONE

                    chipGlobe.visibility = android.view.View.VISIBLE
                    chipInfo.visibility = android.view.View.VISIBLE
                    chipIncharge.visibility = android.view.View.VISIBLE

                    chipIndonesia.visibility = android.view.View.VISIBLE
                    chipIndoCilegon.visibility = android.view.View.GONE
                    chipIndoJakarta.visibility = android.view.View.GONE
                    chipIndoBatam.visibility = android.view.View.GONE
                }
            }
            getString(R.string.globe) -> {
                binding.apply {
                    chipAustralia.visibility = android.view.View.VISIBLE
                    chipSingapore.visibility = android.view.View.VISIBLE

                    chipGlobe.visibility = android.view.View.GONE
                    chipInfo.visibility = android.view.View.GONE
                    chipIncharge.visibility = android.view.View.GONE

                    chipIndonesia.visibility = android.view.View.VISIBLE
                    chipIndoCilegon.visibility = android.view.View.GONE
                    chipIndoJakarta.visibility = android.view.View.GONE
                    chipIndoBatam.visibility = android.view.View.GONE
                }
            }
        }
    }

}